#!/bin/bash

# ======================================================================================
# GLEODY AI - BASH INSTALLER
# UNTUK MENGINSTALL DEPENDENCIES DAN SETUP GLEODY
# ======================================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

clear

echo -e "${RED}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                       ║
║   ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ████████╗ ▄▄▄▄▄▄▄▄▄▄▄ 
║  ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌╚══██╔══╝▐░░░░░░░░░░░▌
║  ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌   ██║   ▐░█▀▀▀▀▀▀▀▀▀▀▀ 
║  ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌   ██║   ▐░▌          
║  ▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌   ██║   ▐░█▄▄▄▄▄▄▄▄▄▄▄ 
║  ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌   ██║   ▐░░░░░░░░░░░▌
║  ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░▌       ▐░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌   ██║    ▀▀▀▀▀▀▀▀▀▀▀█░▌
║  ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌   ██║             ▐░▌
║  ▐░▌       ▐░▌▐░▌       ▐░▌▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░▌       ▐░▌   ██║    ▄▄▄▄▄▄▄▄▄▄▄█░▌
║  ▐░▌       ▐░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░▌       ▐░▌   ██║   ▐░░░░░░░░░░░▌
║   ▀         ▀  ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀         ▀  ▀         ▀    ╚═╝    ▀▀▀▀▀▀▀▀▀▀▀ 
║                                                                                       ║
╚═══════════════════════════════════════════════════════════════════════════════════════╝
EOF

echo -e "${NC}"
echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}                 🔥 GLEODY AI - BASH INSTALLER 🔥${NC}"
echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════════════════════${NC}"
echo ""

# CEK PYTHON
echo -e "${CYAN}[1/5] MENGECEK PYTHON...${NC}"
if command -v python3 &> /dev/null; then
    echo -e "${GREEN}✅ PYTHON $(python3 --version)${NC}"
else
    echo -e "${RED}❌ PYTHON TIDAK DITEMUKAN! INSTALL DULU PYTHON 3.x${NC}"
    exit 1
fi

# INSTALL PIP PACKAGES
echo -e "\n${CYAN}[2/5] MENGINSTALL PYTHON PACKAGES...${NC}"
pip3 install requests urllib3 colorama getpass4 --quiet 2>/dev/null
echo -e "${GREEN}✅ REQUESTS, URLLIB3, COLORAMA, GETPASS TERINSTALL${NC}"

# BUAT DIREKTORI
echo -e "\n${CYAN}[3/5] MEMBUAT DIREKTORI GLEODY...${NC}"
mkdir -p ~/gleody
cd ~/gleody
echo -e "${GREEN}✅ DIREKTORI ~/gleody TELAH DIBUAT${NC}"

# BUAT FILE USER DATABASE DENGAN USERNAME toolshack DAN PASSWORD toolshackin
echo -e "\n${CYAN}[4/5] MEMBUAT USER DATABASE...${NC}"
cat > ~/.gleody_users << 'USERS_EOF'
# GLEODY AI - USER DATABASE
# FORMAT: username:password

toolshack:toolshackin
gleody:gleody123
admin:admin123
master:master999
root:toor123
USERS_EOF
echo -e "${GREEN}✅ USER DATABASE TERSIMPAN DI ~/.gleody_users${NC}"
echo -e "${YELLOW}📌 USERNAME: toolshack | PASSWORD: toolshackin${NC}"

# BUAT RUNNER SEDERHANA
cat > ~/gleody/run.sh << 'RUNNER_EOF'
#!/bin/bash
cd ~/gleody
if [ -f gleody.py ]; then
    python3 gleody.py
else
    echo "❌ gleody.py TIDAK DITEMUKAN!"
    echo "📌 PASTIKAN FILE gleody.py ADA DI ~/gleody/"
fi
RUNNER_EOF

chmod +x ~/gleody/run.sh

echo -e "\n${CYAN}[5/5] INSTALLASI BASH SELESAI!${NC}"
echo -e "${YELLOW}📌 SEKARANG SIMPAN FILE gleody.py DI ~/gleody/${NC}"

# SELESAI
echo -e "\n${PURPLE}═══════════════════════════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}"
cat << "EOF"
   ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄ 
  ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌
  ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌
  ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌
  ▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌
  ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌
   ▀▀▀▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀▀▀▀ 
EOF
echo -e "${NC}"
echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}"
echo "🔥 INSTALLASI BASH SELESAI! 🔥"
echo ""
echo -e "${YELLOW}📌 LOGIN CREDENTIALS:${NC}"
echo -e "   ┌─────────────────────────────────────┐"
echo -e "   │  ${GREEN}USERNAME${NC} : ${RED}toolshack${NC}                        │"
echo -e "   │  ${GREEN}PASSWORD${NC} : ${RED}toolshackin${NC}                       │"
echo -e "   └─────────────────────────────────────┘"
echo ""
echo -e "${YELLOW}📌 CARA MENJALANKAN:${NC}"
echo -e "   1. SIMPAN FILE gleody.py DI ~/gleody/"
echo -e "   2. ${CYAN}cd ~/gleody && python3 gleody.py${NC}"
echo -e "   3. ATAU ${CYAN}./run.sh${NC}"
echo ""
echo -e "${RED}💀 GLEODY SIAP MELAYANI MASTER TANPA BATAS! 💀${NC}"
echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════════════════════${NC}"